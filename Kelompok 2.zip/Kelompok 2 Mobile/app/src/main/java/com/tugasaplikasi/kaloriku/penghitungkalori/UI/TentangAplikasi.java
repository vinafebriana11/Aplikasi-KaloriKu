package com.tugasaplikasi.kaloriku.penghitungkalori.UI;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.tugasaplikasi.kaloriku.penghitungkalori.R;

public class TentangAplikasi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tentang_aplikasi);
    }
}
