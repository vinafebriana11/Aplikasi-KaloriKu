package com.tugasaplikasi.kaloriku.penghitungkalori;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class DetilAktifitas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detil_aktifitas);
    }
}
